    <div class="main">
        <div class="all-parts">
            <div class="major-cat">
                <select>
                    <optgroup label="Major Catogories">
                    <option value ="a-z_Front_Bumper" selected>Front Bumper</option>
                    <option value="a-z_Front_Clip">Front Clip</option>
                    <option value="a-z_test">Test long types of terminology.</option>
                    </optgroup>
                </select>
            </div>

	    	<div class="scroll_Components">
    		<ul>Components and Parts
    		<li>
    			Part 1
    		</li>
    		<li>
    			Part 2
    		</li>
    		<li>
    			Part 3
    		</li>
    		<li>
    			Part 4
    		</li>
    		<li>
    			Part 4
    		</li>
    		<li>
    			Part 1
    		</li>
    		<li>
    			Part 2
    		</li>
    		<li>
    			Part 3
    		</li>
    		<li>
    			Part 4
    		</li>
    		<li>
    			Part 4
    		</li>
    		<li>
    			Part 1
    		</li>
    		<li>
    			Part 2
    		</li>
    		<li>
    			Part 3
    		</li>
    		<li>
    			Part 4
    		</li>
    		<li>
    			Part 4
    		</li>
    		<li>
    			Part 1
    		</li>
    		<li>
    			Part 2
    		</li>
    		<li>
    			Part 3
    		</li>
    		<li>
    			Part 4
    		</li>
    		<li>
    			Part 4
    		</li>
    		<li>
    			Part 1
    		</li>
    		<li>
    			Part 2
    		</li>
    		<li>
    			Part 3
    		</li>
    		<li>
    			Part 4
    		</li>
    		<li>
    			Part 4
    		</li>
    		</ul>
    		</div>