//var frontBody;
function displayMap(diaDisplayMap){
/*	var diaDisplayMap = pram;
	console.log(pram);
	console.log(diaDisplayMap);*/
		mainArea = document.getElementById('main-area');
		mainArea.setAttribute('src', 'images/'+diaDisplayMap+'.jpg');
		mainArea.setAttribute('width', '750');
		mainArea.setAttribute('height', '450');
		mainArea.setAttribute('border', '0');
		mainArea.setAttribute('usemap', '#'+diaDisplayMap);
}

function ajaxcall(){
    $.ajax({
        url: 'actions/writeEst.php',
        type: 'post',
        data: { "callFunc1": "1"},
        success: function(response) { console.log(response); }
    });
}
/*
function roof_Down(){
	roofDown = document.getElementById('main-area');
	roofDown.setAttribute('src', 'images/roof_down.jpg');
}


function replaceMainImg(){
	document.getElementById('main-area').style.display="none";
}

function hood(){
	replaceMainImg();
	mainArea=document.getElementById('main-area');
    frontBody=document.getElementById('front_body');
    var front_body = document.createElement('img');
    front_body.id = 'front_body';
    front_body.setAttribute('src', 'images/frontBody.jpg');
}

function hood(){
	mainArea=document.getElementById('main-area');
	mainArea.setAttribute('src', 'images/frontBody.jpg');
}
*/