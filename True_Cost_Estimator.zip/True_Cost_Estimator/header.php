<?php
  session_start();
?>
<!DOCTYPE html>

<html lang="en">
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>TrueCost Estimator</title>
	<meta name="description" content="">
	<meta name="author" content="Jason Mayberry">
	<link rel="stylesheet" href="css/style.css">
	<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.11.2/jquery.min.js"></script>
</head>
<body>
<?php
$first = $_SESSION['u_first'];
?>
<div class="container">
	    	<nav class="top-bar">
	   			<div class="top-bar">
	   				<div class="top1">
	   					<div>Welcome, <?php echo $first; ?></div>
<?php
	if (isset($_SESSION['u_id'])) {
		echo '<form action="includes/logout.inc.php" method="POST">
			<button type="submit" name="submit">Logout</button>
		</form>';
	} else {
		header("Location: index.php?signup=success");
	}
?>
	   				</div>
	   				<div class="top2">

						<div>History</div>
	   					<div>New Est.</div>
	   				</div>
	   				<div class="top3">
	   					<div>Estimator</div>
	   					<div>Settings</div>
	   				</div>
	    		</div>    		
	    	</nav>
















