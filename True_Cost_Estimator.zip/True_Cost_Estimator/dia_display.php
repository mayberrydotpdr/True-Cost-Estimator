       	<div class="dia-display">
       		<img src="images/main-area-750x450.jpg" id="main-area">
       	</div>
    </div><!-- close of class="main" -->