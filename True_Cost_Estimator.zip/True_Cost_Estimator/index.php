<?php
  session_start();
?>
<!DOCTYPE html>

<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>TrueCost Estimator</title>
  <meta name="description" content="">
  <meta name="author" content="Jason Mayberry">
  <link rel="stylesheet" href="css/style.css">
  <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.11.2/jquery.min.js"></script>
  <style type="text/css">
    input {
      padding: 10px;
      font-size: 12pt;
      margin: 10px
    }
    button {
      padding: 10px;
      font-size: 12pt;
      margin: 10px
    }
    a {
      text-decoration: none;
      color: #000;
    }
  </style>
</head>
<body>
<header>
  <nav>
      <div class="login-signup">
        <?php
          if(isset($_SESSION['u_id'])) {
            header("Location: estimator.php?signup=success");
          } else {
            echo '
              <h1>TrueCost Estimator</h1>
              <form action="includes/login.inc.php" method="POST">
                <input type="text" name="uid" placeholder="Username/e-mail">
                <br>
                <input type="password" name="pwd" placeholder="password">
                <br>
                <button type="submit" name="submit" id="login">Login</button>
              </form>
              <br>
              <i>or</i>
              <br>
              <button> <a href="signup.php">Sign up</a></button>';
          }
        ?>   
    </div>
  </nav>
</header>
</body>
</html>