<!DOCTYPE html>

<html lang="en">
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>TrueCost Estimator</title>
	<meta name="description" content="">
	<meta name="author" content="Jason Mayberry">
	<link rel="stylesheet" href="style.css">
</head>
<body>
<div class="container">
	    	<nav class="top-bar">
	   			<div class="top-bar">
	   				<div class="top1">
	   					<div>Welcome</div>
	   					<div>$UserName</div>	
	   				</div>
	   				<div class="top2">
	   					<div>$LogInOut</div>
						<div>History</div>
	   				</div>
	   				<div class="top3">
	   					<div>New Est.</div>
	   					<div>Estimator</div>
	   					<div>Settings</div>
	   				</div>
	    		</div>    		
	    	</nav>
	<div class="main">
	    <div class="all-parts">
	    	<div class="major-cat">
	    		<select>
	    			<optgroup label="Major Catogories">
	    			<option value ="a-z_Front_Bumper" selected>Front Bumper</option>
	    			<option value="a-z_Front_Clip">Front Clip</option>
	    			<option value="a-z_test">Test long types of terminology.</option>
	    			</optgroup>
	    		</select>
	    	</div>











	    	<div class="scroll_Components">
    		<ul>Components and Parts
    		<li>
    			Part 1
    		</li>
    		<li>
    			Part 2
    		</li>
    		<li>
    			Part 3
    		</li>
    		<li>
    			Part 4
    		</li>
    		<li>
    			Part 4
    		</li>
    		<li>
    			Part 1
    		</li>
    		<li>
    			Part 2
    		</li>
    		<li>
    			Part 3
    		</li>
    		<li>
    			Part 4
    		</li>
    		<li>
    			Part 4
    		</li>
    		<li>
    			Part 1
    		</li>
    		<li>
    			Part 2
    		</li>
    		<li>
    			Part 3
    		</li>
    		<li>
    			Part 4
    		</li>
    		<li>
    			Part 4
    		</li>
    		<li>
    			Part 1
    		</li>
    		<li>
    			Part 2
    		</li>
    		<li>
    			Part 3
    		</li>
    		<li>
    			Part 4
    		</li>
    		<li>
    			Part 4
    		</li>
    		<li>
    			Part 1
    		</li>
    		<li>
    			Part 2
    		</li>
    		<li>
    			Part 3
    		</li>
    		<li>
    			Part 4
    		</li>
    		<li>
    			Part 4
    		</li>
    		</ul>
    		</div>





    		<div class="auto-section">
	    		<form action="/signup" method="post">
				  <p>
				    <label>True Cost Estimator</label><br>
				    <label>
				      <input type="checkbox" name="title" value="Section_Refinish">
				      Section Refinish
				    </label><br>
				    <label>
				      <input type="checkbox" name="title" value="Additional_Labour">
				      Additional Labour
				    </label><br>
				    <label>
				      <input type="checkbox" name="title" value="Labour_Materials">
				      Additional Materials
				    </label><br>
				  </p>
				</form>
				<img src="images/autoAreaMap.jpg" width="170" height="108" border="0" usemap="#map" />
				<map name="map">
				<area shape="poly" coords="44,38,16,54,26,59,43,62,52,60,84,51,90,44,102,31,64,27,46,39" onclick="hood()" />
				<area shape="poly" coords="16,56,12,69,15,81,31,88,55,89,68,89,71,72,69,65,41,67,17,61" onclick="bumper()" />
				<area shape="poly" coords="69,22,87,25,113,29,134,25,132,20,125,13,101,11,84,14" onclick="roof()" />
				<area shape="poly" coords="110,37,102,49,102,74,111,77,137,68,137,47,132,32" onclick="doors()" />
				<area shape="poly" coords="146,21,140,29,143,50,154,59,164,50,158,21" onclick="rearBody()" />
				</map>
    		</div>
       	</div><!-- close of class="all-parts" -->




       	<div class="dia-display">
       		<img src="images/main-area-750x450.jpg" id="main-area">
       		<!--img src="images/frontBody.jpg" id="front_body" -->
       	</div>
    </div><!-- close of class="main" -->





	<div class="table-container">
		<table class="myTable">
			<tr>
				<th>Kind</th>
				<th>Part Description</th>
				<th>Side</th>
				<th>Operation</th>
				<th>Price</th>
				<th>Hours</th>
				<th>Rate</th>
				<th>Adj.</th>
				<th>Bet.</th>
				<th>Line Total</th>
				<th>Notes</th>
			</tr>
			<tr>
				<td>Table cell</td>
				<td>Table cell</td>
				<td>Table cell</td>
				<td>Table cell</td>
				<td>Table cell</td>
				<td>Table cell</td>
				<td>Table cell</td>
				<td>Table cell</td>
				<td>Table cell</td>
				<td>Table cell</td>
				<td>Table cell</td>
			</tr>
			<tr>
				<td>Table cell</td>
				<td>Table cell</td>
				<td>Table cell</td>
				<td>Table cell</td>
				<td>Table cell</td>
				<td>Table cell</td>
				<td>Table cell</td>
				<td>Table cell</td>
				<td>Table cell</td>
				<td>Table cell</td>
				<td>Table cell</td>
			</tr>
			<tr>
				<td>Table cell</td>
				<td>Table cell</td>
				<td>Table cell</td>
				<td>Table cell</td>
				<td>Table cell</td>
				<td>Table cell</td>
				<td>Table cell</td>
				<td>Table cell</td>
				<td>Table cell</td>
				<td>Table cell</td>
				<td>Table cell</td>
			</tr>
		</table>
	</div>




</div><!-- close of class="container" -->
  <script src="js/script.js"></script>
</body>
</html>


















