	<div class="table-container">
		<table class="myTable">
			<tr>
				<th>#</th>
				<th>Kind</th>
				<th>Part Description</th>
				<th>Side</th>
				<th>Operation</th>
				<th>Price</th>
				<th>Hours</th>
				<th>Rate</th>
				<th>Adj.</th>
				<th>Bet.</th>
				<th>Line Total</th>
				<th>Notes</th>
			</tr>
			<tr>
				<td>1</td>
				<td>Table cell</td>
				<td>Table cell</td>
				<td>Table cell</td>
				<td>Table cell</td>
				<td>Table cell</td>
				<td>Table cell</td>
				<td>Table cell</td>
				<td>Table cell</td>
				<td>Table cell</td>
				<td>Table cell</td>
				<td>Table cell</td>				
			</tr>
			<tr>
				<td>2</td>
				<td>Table cell</td>
				<td>Table cell</td>
				<td>Table cell</td>
				<td>Table cell</td>
				<td>Table cell</td>
				<td>Table cell</td>
				<td>Table cell</td>
				<td>Table cell</td>
				<td>Table cell</td>
				<td>Table cell</td>
				<td>Table cell</td>
			</tr>
			<tr>
				<td>3</td>
				<td>Table cell</td>
				<td>Table cell</td>
				<td>Table cell</td>
				<td>Table cell</td>
				<td>Table cell</td>
				<td>Table cell</td>
				<td>Table cell</td>
				<td>Table cell</td>
				<td>Table cell</td>
				<td>Table cell</td>
				<td>Table cell</td>
			</tr>
		</table>
	</div>