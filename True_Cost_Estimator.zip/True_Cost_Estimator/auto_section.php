    		<div class="auto-section">
	    		<form action="/signup" method="post">
				  <p>
				    <label>True Cost Estimator</label><br>
				    <label>
				      <input type="checkbox" name="title" value="Section_Refinish">
				      Section Refinish
				    </label><br>
				    <label>
				      <input type="checkbox" name="title" value="Additional_Labour">
				      Additional Labour
				    </label><br>
				    <label>
				      <input type="checkbox" name="title" value="Labour_Materials">
				      Additional Materials
				    </label><br>
				  </p>
				</form>
				<img src="images/autoAreaMap.jpg" width="170" height="108" border="0" usemap="#autoAreaMap" />
				<map name="autoAreaMap">
				<area shape="poly" coords="44,38,16,54,26,59,43,62,52,60,84,51,90,44,102,31,64,27,46,39" onclick="displayMap('frontBody')" />
				<area shape="poly" coords="16,56,12,69,15,81,31,88,55,89,68,89,71,72,69,65,41,67,17,61" onclick="displayMap('frontBumper')" />
				<area shape="poly" coords="69,22,87,25,113,29,134,25,132,20,125,13,101,11,84,14" onclick="displayMap('roofDown')" />
				<area shape="poly" coords="110,37,102,49,102,74,111,77,137,68,137,47,132,32" onclick="displayMap('doors')" />
				<area shape="poly" coords="146,21,140,29,143,50,154,59,164,50,158,21" onclick="displayMap('rearBody')" />
				</map>
    		</div>
       	</div><!-- close of class="all-parts" -->