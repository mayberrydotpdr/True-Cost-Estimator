<!DOCTYPE html>

<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>TrueCost Estimator</title>
  <meta name="description" content="">
  <meta name="author" content="Jason Mayberry">
  <link rel="stylesheet" href="css/style.css">
  <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.11.2/jquery.min.js"></script>
  <style type="text/css">
    input {
      padding: 10px;
      font-size: 12pt;
      margin: 10px
    }
    button {
      padding: 10px;
      font-size: 12pt;
      margin: 10px
    }
    a {
      text-decoration: none;
      color: #000;
    }
  </style>
</head>
<body>
<header>
  <nav>
      <div class="login-signup">
        <?php
          if(isset($_SESSION['u_id'])) {
            echo 'You are Signed in as'. $uid;
          } else {
            echo '
              <section class="main-container">
                <div class="main-wrapper">
                  <h2>Signup for TrueCost Estimator</h2>
                  <form class="signup-form" action="includes/signup.inc.php" method="POST">
                    <input type="text" name="first" placeholder="Firstname">
                    <br>
                    <input type="text" name="last" placeholder="Lastname">
                    <br>
                    <input type="text" name="email" placeholder="E-mail">
                    <br>
                    <input type="text" name="uid" placeholder="Username">
                    <br>
                    <input type="password" name="pwd" placeholder="Password">
                    <br>
                    <button type="submit" name="submit">Sign up</button>
                  </form>
                </div>
              </section>';
          }
        ?>   
    </div>
  </nav>
</header>
</body>
</html>