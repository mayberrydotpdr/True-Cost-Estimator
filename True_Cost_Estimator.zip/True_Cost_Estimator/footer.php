</div><!-- close of class="container" -->
  <script src="js/script.js"></script>
</body>
</html>